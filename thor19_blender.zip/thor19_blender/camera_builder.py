"""
THOR19 — camera_builder.py
Create an orthographic Blender camera from a THOR19 artboard descriptor.

CAMERA DESIGN — THOR19 WYSIWYG 2D WORKFLOW
===========================================

Goal: Camera View in Blender must look identical to the Illustrator artboard.

Coordinate system used by THOR19 curves (from curve_builder._v3):

    Curve world position for a point at (ai_x, ai_y) in Illustrator:
        world_x = -(ai_x - artboard_cx)     →  AI-right → world -X
        world_y =  (ai_y - artboard_cy)     →  AI-top   → world +Y

    Therefore:
        AI left  side → world +X
        AI right side → world -X
        AI top        → world +Y
        AI bottom     → world -Y

Required camera frame mapping:
        screen LEFT  ← world +X   (AI left)
        screen RIGHT ← world -X   (AI right)
        screen TOP   ← world +Y   (AI top)
        screen BOTTOM← world -Y   (AI bottom)

Derived camera configuration:
    screen LEFT  = world +X  →  cam local +X (screen right) must map to world -X
    screen TOP   = world +Y  →  cam local +Y (screen up)    must map to world +Y

    Euler Y=180° produces:
        cam local +X → world -X  ✓
        cam local +Y → world +Y  ✓
        cam local -Z → world +Z  (camera looks toward +Z)

    Camera must be placed at negative Z to look toward artwork at Z=0:
        position = (0, 0, -CAMERA_Z)
        looking toward +Z → sees artwork at Z=0 ✓

Final camera parameters:
    location       = (0.0, 0.0, -CAMERA_Z)
    rotation_euler = (0°, 180°, 0°)  Euler XYZ
    type           = ORTHO
    ortho_scale    = artboard_height * scale
    sensor_fit     = VERTICAL
"""

from __future__ import annotations

import logging
import math

import bpy
import mathutils

log = logging.getLogger(__name__)

_CAMERA_OBJ_NAME  = "THOR19_Camera"
_CAMERA_DATA_NAME = "THOR19_Camera_Data"
_CAMERA_Z         = 100.0   # distance from artwork plane (Z=0)


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def build_camera(
    artboard: dict,
    root_collection: bpy.types.Collection,
    scale: float = 1.0,
    set_active: bool = True,
    set_render_resolution: bool = True,
) -> bpy.types.Object:
    """
    Create (or replace) the THOR19 orthographic camera.

    The camera is always placed at (0, 0, -CAMERA_Z) with rotation (0°,180°,0°)
    so that Camera View in Blender matches the Illustrator artboard exactly.

    Parameters
    ----------
    artboard : dict
        Artboard descriptor. Required keys: width, height.
    root_collection : bpy.types.Collection
    scale : float
        1 Blender unit = 1 Illustrator point when scale=1.0.
    set_active : bool
    set_render_resolution : bool

    Returns
    -------
    bpy.types.Object
    """
    _remove_existing_camera()

    # ── Artboard dimensions ───────────────────────────────────────────────────
    width_pts:  float = float(artboard.get("width",  0.0))
    height_pts: float = float(artboard.get("height", 0.0))

    # Fallback: derive from raw artboard rect if width/height absent or zero
    if width_pts <= 0.0 or height_pts <= 0.0:
        ab_left   = float(artboard.get("left",   0.0))
        ab_right  = float(artboard.get("right",  0.0))
        ab_top    = float(artboard.get("top",    0.0))
        ab_bottom = float(artboard.get("bottom", 0.0))
        width_pts  = abs(ab_right  - ab_left)
        height_pts = abs(ab_top    - ab_bottom)
        log.warning(
            "Artboard width/height missing — computed from rect: %.0f × %.0f pt",
            width_pts, height_pts,
        )

    if height_pts <= 0.0:
        height_pts = 1080.0
        log.warning("Artboard height still zero after fallback — using default 1080 pt.")

    width_bu:  float = width_pts  * scale
    height_bu: float = height_pts * scale

    # ── Camera data-block ─────────────────────────────────────────────────────
    cam_data: bpy.types.Camera = bpy.data.cameras.new(name=_CAMERA_DATA_NAME)
    cam_data.type = "ORTHO"

    # ortho_scale = total height of the visible area in world units.
    # With sensor_fit=VERTICAL this is independent of viewport aspect ratio.
    # Setting it to artboard_height guarantees the full artboard height is
    # always visible in Camera View.
    cam_data.ortho_scale = height_bu
    cam_data.sensor_fit  = "VERTICAL"

    # Camera is at -CAMERA_Z, artwork is at Z=0.
    # Distance = CAMERA_Z. clip_end must be > CAMERA_Z.
    cam_data.clip_start = 0.1
    cam_data.clip_end   = _CAMERA_Z * 2.0

    # ── Camera object ─────────────────────────────────────────────────────────
    cam_obj: bpy.types.Object = bpy.data.objects.new(
        name=_CAMERA_OBJ_NAME, object_data=cam_data
    )

    # ── POSITION: (0, 0, -CAMERA_Z) ──────────────────────────────────────────
    # Camera sits below the artwork plane (Z=0), looking upward toward +Z.
    # World origin = artboard centre, so camera is centred on the artboard.
    cam_obj.location = mathutils.Vector((0.0, 0.0, -_CAMERA_Z))

    # ── ROTATION: Euler XYZ = (0°, 180°, 0°) ─────────────────────────────────
    # Rotation Y=180° transforms camera local axes as follows:
    #
    #   cam local +X (screen right) → world -X
    #   cam local +Y (screen up)    → world +Y   [unchanged]
    #   cam local -Z (forward)      → world +Z   [now looks toward +Z]
    #
    # From position (0,0,-100) looking toward +Z: camera sees Z=0 plane ✓
    #
    # Combined with curve world coordinates:
    #   AI left  (world +X) → projects to screen -X → appears LEFT  ✓
    #   AI right (world -X) → projects to screen +X → appears RIGHT ✓
    #   AI top   (world +Y) → projects to screen +Y → appears TOP   ✓
    #   AI bottom(world -Y) → projects to screen -Y → appears BOTTOM✓
    cam_obj.rotation_euler = mathutils.Euler(
        (0.0, math.radians(180.0), 0.0), "XYZ"
    )

    # ── Link to collection ────────────────────────────────────────────────────
    root_collection.objects.link(cam_obj)

    # ── Set as active scene camera ────────────────────────────────────────────
    scene = bpy.context.scene
    if set_active:
        scene.camera = cam_obj

    # ── Sync render resolution to artboard dimensions ─────────────────────────
    # At Illustrator's default 72 PPI: 1 point = 1 pixel.
    # This makes the render output a pixel-perfect match of the artboard.
    if set_render_resolution:
        _sync_render_resolution(scene, width_pts, height_pts)

    log.info(
        "THOR19 Camera: pos=(0, 0, %.0f)  rot=(0°, 180°, 0°)  "
        "ortho_scale=%.1f bu  artboard='%s' %.0f×%.0f pt",
        -_CAMERA_Z,
        cam_data.ortho_scale,
        artboard.get("name", "?"),
        width_pts,
        height_pts,
    )

    return cam_obj


def align_viewport_to_camera(context: bpy.types.Context) -> None:
    """
    Switch every visible 3D viewport to Camera View.

    Called after import so the user immediately sees the THOR19 camera
    view without having to press Numpad 0 manually.
    """
    for area in context.screen.areas:
        if area.type != "VIEW_3D":
            continue
        for space in area.spaces:
            if space.type == "VIEW_3D":
                space.region_3d.view_perspective = "CAMERA"
                break


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _sync_render_resolution(
    scene: bpy.types.Scene,
    width_pts: float,
    height_pts: float,
) -> None:
    """Set scene render resolution to match the artboard in pixels (72 PPI)."""
    w = max(1, int(round(width_pts)))
    h = max(1, int(round(height_pts)))
    scene.render.resolution_x          = w
    scene.render.resolution_y          = h
    scene.render.resolution_percentage = 100
    log.debug("Render resolution: %d × %d px", w, h)


def _remove_existing_camera() -> None:
    """Remove the THOR19 camera object and data-block if they exist."""
    obj = bpy.data.objects.get(_CAMERA_OBJ_NAME)
    if obj is not None:
        for coll in list(obj.users_collection):
            coll.objects.unlink(obj)
        bpy.data.objects.remove(obj, do_unlink=True)
        log.debug("Removed old camera object '%s'.", _CAMERA_OBJ_NAME)

    data = bpy.data.cameras.get(_CAMERA_DATA_NAME)
    if data is not None:
        bpy.data.cameras.remove(data)
        log.debug("Removed old camera data '%s'.", _CAMERA_DATA_NAME)
