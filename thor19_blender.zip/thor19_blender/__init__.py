"""
THOR19 Blender Addon — __init__.py  v2 UPGRADED
Adobe Illustrator → Blender Vector Bridge

UPGRADE v2:
- last_scale property added to scene properties (used by Reload)
- All v2 sub-modules imported
- Compatible: Blender 4.5 / Python 3.11
"""

bl_info = {
    "name":        "THOR19 — AI→Blender Vector Bridge",
    "author":      "THOR19 Pipeline",
    "version":     (2, 0, 0),
    "blender":     (4, 5, 0),
    "location":    "View3D › N Panel › THOR19",
    "description": "Import Adobe Illustrator vector scenes via thor19_scene.json",
    "category":    "Import-Export",
}

import bpy
import logging

from . import importer, ui_panel

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Scene Properties
# ─────────────────────────────────────────────────────────────────────────────

class THOR19_SceneProperties(bpy.types.PropertyGroup):
    """THOR19 settings stored per Blender scene (survives file saves)."""

    json_path: bpy.props.StringProperty(
        name        = "Scene JSON",
        description = "Path to the thor19_scene.json file",
        default     = "",
        subtype     = "FILE_PATH",
    )  # type: ignore

    import_status: bpy.props.StringProperty(
        name        = "Status",
        description = "Last import operation result",
        default     = "No scene loaded.",
    )  # type: ignore

    last_layer_count: bpy.props.IntProperty(
        name="Layer Count", default=0
    )  # type: ignore

    last_path_count: bpy.props.IntProperty(
        name="Curve Count", default=0
    )  # type: ignore

    last_scale: bpy.props.FloatProperty(
        name        = "Last Scale",
        description = "Scale used in the last import — reused by Reload",
        default     = 1.0,
        min         = 0.0,
    )  # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
#  Registration
# ─────────────────────────────────────────────────────────────────────────────

_CLASSES = [
    THOR19_SceneProperties,
    importer.THOR19_OT_ImportScene,
    importer.THOR19_OT_ReloadScene,
    ui_panel.THOR19_PT_MainPanel,
    ui_panel.THOR19_PT_StatusPanel,
]


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.thor19 = bpy.props.PointerProperty(type=THOR19_SceneProperties)
    log.info("THOR19 v2 addon registered.")


def unregister() -> None:
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Scene, "thor19"):
        del bpy.types.Scene.thor19
    log.info("THOR19 v2 addon unregistered.")


if __name__ == "__main__":
    register()
