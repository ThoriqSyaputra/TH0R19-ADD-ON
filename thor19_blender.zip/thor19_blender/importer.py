"""
THOR19 — importer.py  v2 UPGRADED
Blender Operators: Import Scene and Reload Scene.

UPGRADE v2 — Clean Refresh (Major Upgrade 7):
----------------------------------------------
Both Import and Reload call the same _perform_import() pipeline.
_perform_import() starts by calling ensure_root_collection() which
performs a full recursive purge of the existing THOR19 collection
before rebuilding — guaranteeing no duplicate collections, cameras,
or curves regardless of how many times Reload is called.

Scale is stored in scene properties after each import so Reload
uses the same scale that was last used for Import.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Dict, List, Set

import bpy
from bpy_extras.io_utils import ImportHelper

from . import collection_builder, curve_builder, camera_builder

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  JSON loading
# ─────────────────────────────────────────────────────────────────────────────

class THOR19JSONError(Exception):
    """Raised when JSON is valid but missing required THOR19 keys."""


def _load_json(filepath: str) -> dict:
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")

    with open(filepath, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    required = {"version", "artboard", "layers", "paths"}
    missing = required - set(data.keys())
    if missing:
        raise THOR19JSONError(
            f"Missing required keys: {', '.join(sorted(missing))}"
        )
    return data


# ─────────────────────────────────────────────────────────────────────────────
#  Core pipeline
# ─────────────────────────────────────────────────────────────────────────────

def _perform_import(
    filepath: str,
    scene: bpy.types.Scene,
    scale: float,
) -> str:
    """
    Full THOR19 import pipeline.

    1. Parse JSON
    2. Detect JSON version (v1 vs v2) for coordinate transform
    3. Purge/create root collection
    4. Build Collection hierarchy
    5. Build orthographic camera (always at world origin)
    6. Build Bezier curves (with version-correct coordinate transform)
    7. Update scene properties

    Returns
    -------
    str  Human-readable status.
    """
    log.info("THOR19 import: %s", filepath)

    data         = _load_json(filepath)
    json_version = str(data.get("version", "1.0")).strip()
    artboard     = data["artboard"]
    layers       = data["layers"]
    paths        = data["paths"]

    log.info(
        "JSON v%s loaded — artboard='%s', layers=%d, paths=%d",
        json_version,
        artboard.get("name", "?"),
        len(layers), len(paths),
    )

    # ── 1. Root collection (purges old scene first) ───────────────────────────
    root_coll = collection_builder.ensure_root_collection(scene, root_name="THOR19")

    # ── 2. Layer collections ──────────────────────────────────────────────────
    uuid_to_coll = collection_builder.build_collections(layers, root_coll)

    # ── 3. Camera ─────────────────────────────────────────────────────────────
    # Camera is always placed at (0, 0, CAMERA_Z) — world origin = artboard centre.
    # camera_builder no longer reads center_x/center_y from JSON.
    camera_builder.build_camera(
        artboard               = artboard,
        root_collection        = root_coll,
        scale                  = scale,
        set_active             = True,
        set_render_resolution  = True,
    )

    # ── 4. Curves ─────────────────────────────────────────────────────────────
    # Pass json_version and artboard so curve_builder can apply the correct
    # coordinate transform:
    #   v2 → coordinates already artboard-centre-relative + Y-flipped: use as-is
    #   v1 → raw Illustrator coords: apply centre offset (no Y flip needed for v1)
    curves_created = curve_builder.build_curves(
        paths              = paths,
        uuid_to_collection = uuid_to_coll,
        root_collection    = root_coll,
        scale              = scale,
        artboard           = artboard,
        json_version       = json_version,
    )

    # ── 5. Persist state ──────────────────────────────────────────────────────
    props = scene.thor19
    props.last_layer_count = len(layers)
    props.last_path_count  = curves_created
    props.last_scale       = scale

    status = (
        f"OK  {artboard.get('name', '?')}  "
        f"{artboard.get('width', 0):.0f}×{artboard.get('height', 0):.0f} pt  "
        f"| {len(layers)} layer(s) | {curves_created} curve(s)"
    )
    log.info("THOR19 import done: %s", status)
    return status


# ─────────────────────────────────────────────────────────────────────────────
#  Operator: Import Scene
# ─────────────────────────────────────────────────────────────────────────────

class THOR19_OT_ImportScene(bpy.types.Operator, ImportHelper):
    """Select a thor19_scene.json and import it as a Blender scene."""

    bl_idname      = "thor19.import_scene"
    bl_label       = "Import THOR19 Scene"
    bl_description = "Choose a thor19_scene.json exported from Adobe Illustrator"
    bl_options     = {"REGISTER", "UNDO"}

    filename_ext: str = ".json"  # type: ignore
    filter_glob: bpy.props.StringProperty(  # type: ignore
        default="*.json", options={"HIDDEN"}
    )

    scale: bpy.props.FloatProperty(  # type: ignore
        name        = "Scale",
        description = "1 Blender unit = 1 Illustrator point at scale 1.0",
        default     = 1.0,
        min         = 0.0001,
        max         = 1000.0,
        soft_min    = 0.001,
        soft_max    = 10.0,
        precision   = 6,
    )

    def execute(self, context: bpy.types.Context) -> Set[str]:
        props    = context.scene.thor19
        filepath = bpy.path.abspath(self.filepath)

        try:
            status = _perform_import(filepath, context.scene, self.scale)
        except FileNotFoundError as exc:
            return self._fail(props, f"File not found: {exc}")
        except (json.JSONDecodeError, THOR19JSONError) as exc:
            return self._fail(props, f"Invalid JSON: {exc}")
        except Exception as exc:
            log.exception("Unexpected import error.")
            return self._fail(props, f"Import failed: {exc}")

        props.json_path     = filepath
        props.import_status = status

        # Snap all 3D viewports to Camera View so the result is immediately
        # visible without the user pressing Numpad 0 manually.
        camera_builder.align_viewport_to_camera(context)

        self.report({"INFO"}, f"THOR19: {status}")
        return {"FINISHED"}

    def _fail(self, props, msg: str) -> Set[str]:
        self.report({"ERROR"}, msg)
        props.import_status = f"ERROR — {msg}"
        return {"CANCELLED"}


# ─────────────────────────────────────────────────────────────────────────────
#  Operator: Reload Scene
# ─────────────────────────────────────────────────────────────────────────────

class THOR19_OT_ReloadScene(bpy.types.Operator):
    """
    Re-import the scene from the last loaded JSON path.

    Completely replaces the existing THOR19 scene (collections, camera,
    curves) with a clean rebuild — no duplicates guaranteed.
    """

    bl_idname      = "thor19.reload_scene"
    bl_label       = "Reload Scene"
    bl_description = "Re-import from the last loaded thor19_scene.json (clean rebuild)"
    bl_options     = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        props = context.scene.thor19
        return bool(props.json_path and props.json_path.strip())

    def execute(self, context: bpy.types.Context) -> Set[str]:
        props    = context.scene.thor19
        filepath = bpy.path.abspath(props.json_path)
        # Reuse the scale that was used during the last import
        scale    = props.last_scale if props.last_scale > 0 else 1.0

        try:
            status = _perform_import(filepath, context.scene, scale)
        except FileNotFoundError as exc:
            return self._fail(props, f"File not found: {exc}")
        except (json.JSONDecodeError, THOR19JSONError) as exc:
            return self._fail(props, f"Invalid JSON: {exc}")
        except Exception as exc:
            log.exception("Unexpected reload error.")
            return self._fail(props, f"Reload failed: {exc}")

        props.import_status = status

        # Snap all 3D viewports to Camera View.
        camera_builder.align_viewport_to_camera(context)

        self.report({"INFO"}, f"THOR19 Reload: {status}")
        return {"FINISHED"}

    def _fail(self, props, msg: str) -> Set[str]:
        self.report({"ERROR"}, msg)
        props.import_status = f"ERROR — {msg}"
        return {"CANCELLED"}
