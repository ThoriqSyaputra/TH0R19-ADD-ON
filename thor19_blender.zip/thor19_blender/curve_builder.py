"""
THOR19 — curve_builder.py  v2 BUGFIX
Create native Blender Bezier Curve objects from THOR19 path descriptors.

BUGFIX — Coordinate Transform (handle both JSON v1 and v2):
------------------------------------------------------------
JSON v2 (exporter v2): coordinates are already artboard-centre-relative
  and Y-axis is already flipped.  Import as-is.

JSON v1 (exporter v1): coordinates are raw Illustrator document space.
  Illustrator internal coordinate system:
    - Origin: bottom-left of document canvas
    - Y positive = UP (toward top of document)
    - Artboard: top > bottom numerically  (e.g. top=1080, bottom=0)
  
  Required transform for Blender:
    offset_x = artboard.left + artboard.width  / 2   (artboard centre X)
    offset_y = artboard.top  - artboard.height / 2   (artboard centre Y in AI space)
    
    blender_x =   (ai_x - offset_x)          # shift so centre = 0
    blender_y = - (ai_y - offset_y)           # flip Y: AI Y-up → Blender Y-up
                                               # but AI Y-up from bottom, artboard
                                               # visual top is at max Y in AI coords.
                                               # Negating makes artboard top = +Y in Blender.

  The importer detects version via the "version" field in the JSON root,
  then passes the appropriate transform parameters to build_curves().

Compound paths:
  All sub-paths sharing a compound_id are merged into one Curve object
  with multiple Bezier splines.

Handle types:
  All handles are set to FREE so Illustrator handle positions are
  preserved exactly.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import bpy
import mathutils

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def build_curves(
    paths: List[dict],
    uuid_to_collection: Dict[str, bpy.types.Collection],
    root_collection: bpy.types.Collection,
    scale: float = 1.0,
    artboard: Optional[dict] = None,
    json_version: str = "2.0",
) -> int:
    """
    Create Blender Bezier Curve objects from THOR19 path descriptors.

    Parameters
    ----------
    paths : list[dict]
    uuid_to_collection : dict[str, Collection]
    root_collection : Collection
    scale : float
    artboard : dict | None
        Artboard descriptor from JSON.  Required when json_version is "1.0"
        so the importer can compute the centre-offset transform itself.
    json_version : str
        "2.0" → coordinates already centre-relative and Y-flipped (no transform needed).
        "1.0" → raw Illustrator document coordinates; importer applies transform.

    Returns
    -------
    int  — number of Curve objects created
    """
    # ── Compute coordinate transform offsets ─────────────────────────────────
    # These are applied inside _v3() for every point.
    #
    # For JSON v2: exporter already subtracted artboard centre and flipped Y.
    #   offset_x = 0,  offset_y = 0,  flip_y = False  (Y already correct)
    #
    # For JSON v1: raw AI coordinates.  We must:
    #   1. Subtract artboard centre so centre → (0,0)
    #   2. Negate Y so Illustrator visual top → positive Blender Y
    #
    # Illustrator artboard in AI internal space:
    #   left, top, right, bottom  where top > bottom (Y positive = up in AI)
    #   artboard centre X = (left + right) / 2
    #   artboard centre Y = (top + bottom) / 2
    #   → subtract these from every point, then negate Y.

    offset_x: float = 0.0
    offset_y: float = 0.0
    needs_transform: bool = False   # v2: already correct, skip transform

    if json_version != "2.0" and artboard is not None:
        # ── JSON v1 — compute offsets in v1 JSON space ───────────────────────
        # v1 JSX formula:
        #   json_x =  ai_x - ab_left       → range [0 .. width]
        #   json_y = -(ai_y - ab_top)      → range [0 .. height]  (0 at top)
        #
        # To centre: subtract half-width / half-height.
        # To correct Y direction: negate after subtracting.
        # (done inside _v3 as:  bx = raw_x - width/2,  by = -(raw_y - height/2))
        #
        # offset_x = width/2   (not ab_left+ab_right)/2 which is AI doc coords)
        # offset_y = height/2  (not (ab_top+ab_bottom)/2)
        width_pts  = float(artboard.get("width",  0.0))
        height_pts = float(artboard.get("height", 0.0))

        # Fallback if width/height missing
        if width_pts <= 0.0 or height_pts <= 0.0:
            ab_left   = float(artboard.get("left",   0.0))
            ab_right  = float(artboard.get("right",  0.0))
            ab_top    = float(artboard.get("top",    0.0))
            ab_bottom = float(artboard.get("bottom", 0.0))
            width_pts  = abs(ab_right  - ab_left)
            height_pts = abs(ab_top    - ab_bottom)

        offset_x = width_pts  / 2.0
        offset_y = height_pts / 2.0
        needs_transform = True

        log.info(
            "JSON v1 detected: centre offset (%.4f, %.4f) from artboard %s×%s pt.",
            offset_x, offset_y, width_pts, height_pts,
        )
    else:
        log.info("JSON v2 detected: applying Y-negation to correct Blender Y-up convention.")

    # ── Group by compound_id (or individual id for simple paths) ─────────────
    groups: Dict[str, List[dict]] = defaultdict(list)
    for path in paths:
        compound_id: Optional[str] = path.get("compound_id")
        group_key = compound_id if compound_id else path["id"]
        groups[group_key].append(path)

    curves_created = 0
    for group_key, group_paths in groups.items():
        try:
            _build_curve_object(
                group_paths,
                uuid_to_collection,
                root_collection,
                scale,
                offset_x,
                offset_y,
                needs_transform,
            )
            curves_created += 1
        except Exception as exc:
            log.error("Failed to build curve group '%s': %s", group_key, exc, exc_info=True)

    log.info(
        "Built %d curve object(s) from %d path descriptor(s).",
        curves_created, len(paths),
    )
    return curves_created


# ─────────────────────────────────────────────────────────────────────────────
#  Internal builders
# ─────────────────────────────────────────────────────────────────────────────

def _build_curve_object(
    group_paths: List[dict],
    uuid_to_collection: Dict[str, bpy.types.Collection],
    root_collection: bpy.types.Collection,
    scale: float,
    offset_x: float,
    offset_y: float,
    needs_transform: bool,
) -> bpy.types.Object:
    primary  = group_paths[0]
    obj_name = primary.get("name", "Curve")

    # ── Curve data-block ──────────────────────────────────────────────────────
    curve_data: bpy.types.Curve = bpy.data.curves.new(name=obj_name, type="CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 12

    # ── Add one Bezier spline per path in the group ───────────────────────────
    first = True
    for path_dict in group_paths:
        points_data: List[dict] = path_dict.get("points", [])
        if not points_data:
            log.warning("Path '%s' has no points — skipping.", path_dict.get("id", "?"))
            continue

        if first:
            spline = curve_data.splines.new(type="BEZIER")
            first = False
        else:
            spline = curve_data.splines.new(type="BEZIER")

        _fill_spline(
            spline,
            points_data,
            bool(path_dict.get("closed", False)),
            scale,
            offset_x,
            offset_y,
            needs_transform,
        )

    if first:
        # All paths in group were empty — clean up and skip
        bpy.data.curves.remove(curve_data)
        log.warning("Curve group '%s' had no usable points — skipped.", obj_name)
        return None  # type: ignore

    # ── Object ────────────────────────────────────────────────────────────────
    obj: bpy.types.Object = bpy.data.objects.new(name=obj_name, object_data=curve_data)

    layer_id: str = primary.get("layer_id", "")
    target_collection = uuid_to_collection.get(layer_id, root_collection)
    target_collection.objects.link(obj)

    log.debug(
        "Curve '%s': %d spline(s) → collection '%s'.",
        obj_name, len(curve_data.splines), target_collection.name,
    )
    return obj


def _fill_spline(
    spline: bpy.types.Spline,
    points_data: List[dict],
    is_closed: bool,
    scale: float,
    offset_x: float,
    offset_y: float,
    needs_transform: bool,
) -> None:
    """
    Populate a Bezier spline from THOR19 point descriptors.

    For JSON v2: offset_x=0, offset_y=0, needs_transform=False.
      Coordinates are already artboard-centre-relative and Y-flipped.
      We only multiply by scale.

    For JSON v1: needs_transform=True.
      We subtract (offset_x, offset_y) to move artboard centre to origin,
      then negate Y to convert Illustrator Y-up-from-bottom to Blender Y-up.

    In both cases the result is:
      Artboard centre → Blender (0, 0, 0)
      X: left of artboard = negative X, right = positive X  (no mirroring)
      Y: top of artboard  = positive Y, bottom = negative Y
    """
    n = len(points_data)
    if n > 1:
        spline.bezier_points.add(n - 1)

    for i, pt_data in enumerate(points_data):
        bp: bpy.types.BezierSplinePoint = spline.bezier_points[i]

        bp.co           = _v3(pt_data["anchor"],       scale, offset_x, offset_y, needs_transform)
        bp.handle_left  = _v3(pt_data["handle_left"],  scale, offset_x, offset_y, needs_transform)
        bp.handle_right = _v3(pt_data["handle_right"], scale, offset_x, offset_y, needs_transform)

        # FREE: preserve Illustrator handle positions exactly.
        # A handle coincident with the anchor = corner/cusp node.
        bp.handle_left_type  = "FREE"
        bp.handle_right_type = "FREE"

    spline.use_cyclic_u = is_closed


# ─────────────────────────────────────────────────────────────────────────────
#  Coordinate helper
# ─────────────────────────────────────────────────────────────────────────────

def _v3(
    point_dict: dict,
    scale: float,
    offset_x: float,
    offset_y: float,
    needs_transform: bool,
) -> mathutils.Vector:
    """
    Convert a THOR19 {x, y} point to mathutils.Vector(bx, by, 0).

    ── Coordinate space summary ─────────────────────────────────────────────────

    Illustrator AI internal space:
        Origin: bottom-left of document canvas
        X: left → right  (positive = right)
        Y: bottom → top  (positive = UP)
        Artboard: top > bottom  (e.g. top=1920, bottom=0)

    Camera convention (Blender ortho, rotation Z=180°):
        Camera is at (0, 0, Z) looking toward -Z.
        With rotation_euler.z = π (180°):
            Camera +X  →  screen LEFT
            Camera -X  →  screen RIGHT
            Camera +Y  →  screen TOP
        Therefore to match Illustrator left=left / right=right layout:
            World -X must be on the LEFT  → bx = -relative_x
            World +Y must be on the TOP   → by = +relative_y from artboard top

    ── JSON v2  (needs_transform=False) ────────────────────────────────────────

    JSX v2 exporter formula:
        json_x =  (ai_x - cx)      cx = artboard centre X
        json_y = -(ai_y - cy)      cy = artboard centre Y  [Y-negated!]

    json_y sign convention:
        Top of artboard:    ai_y=top  → json_y = -(top-cy)  = -cy   (negative)
        Bottom of artboard: ai_y=0    → json_y = -(0-cy)    = +cy   (positive)

    json_y is negative at the top → opposite of Blender +Y-up convention.
    So: by = -json_y  (re-negate to get +Y at top)

    json_x is already centred and correct sign (positive = right in world).
    Camera Z=180° flips left↔right in the frame.
    So: bx = -json_x  (pre-flip so camera Z=180° restores correct orientation)

    Result:
        bx = -raw_x * scale
        by = -raw_y * scale

    Verify (1080×1920 artboard, cx=540, cy=960):
        top-left  AI(0,1920)  → JSON(-540,-960) → Blender(+540,+960)
            Camera Z=180° sees +X as LEFT → appears at LEFT = correct ✓
        top-right AI(1080,1920) → JSON(+540,-960) → Blender(-540,+960)
            Camera Z=180° sees -X as RIGHT → appears at RIGHT = correct ✓

    ── JSON v1  (needs_transform=True) ─────────────────────────────────────────

    JSX v1 exporter formula:
        json_x =  ai_x - ab_left     (range [0..width],  0 at left)
        json_y = -(ai_y - ab_top)    (range [0..height], 0 at top)

    offset_x = width  / 2   (to centre horizontally)
    offset_y = height / 2   (to centre vertically)

    Applying same camera-Z=180° compensation:
        bx = -(json_x - offset_x) * scale    (flip X for camera Z=180°)
        by = -(json_y - offset_y) * scale    (re-flip Y: top→positive)

    Verify (1080×1920, offset_x=540, offset_y=960):
        top-left  v1(0,0):      bx=-(0-540)=+540, by=-(0-960)=+960
            Camera Z=180° → LEFT = correct ✓
        top-right v1(1080,0):   bx=-(1080-540)=-540, by=-(0-960)=+960
            Camera Z=180° → RIGHT = correct ✓
        centre    v1(540,960):  bx=0, by=0 ✓
    """
    raw_x: float = float(point_dict.get("x", 0.0))
    raw_y: float = float(point_dict.get("y", 0.0))

    if needs_transform:
        # JSON v1: centre, flip X (camera Z=180° compensation), re-negate Y.
        bx = -(raw_x - offset_x) * scale
        by = -(raw_y - offset_y) * scale
    else:
        # JSON v2: flip X (camera Z=180° compensation), negate Y.
        bx = -raw_x * scale
        by = -raw_y * scale

    return mathutils.Vector((bx, by, 0.0))
