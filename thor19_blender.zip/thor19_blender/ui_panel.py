"""
THOR19 — ui_panel.py  v2 UPGRADED
N-Panel UI panels for THOR19 Blender addon.

UPGRADE v2:
- Shows artboard dimensions from last import
- Reload button uses saved scale (no re-entry needed)
- Status panel expanded by default
- Scale field shown in Import sub-section
- Cleaner layout with icon-labelled stats
"""

from __future__ import annotations

import bpy


# ─────────────────────────────────────────────────────────────────────────────
#  Main panel
# ─────────────────────────────────────────────────────────────────────────────

class THOR19_PT_MainPanel(bpy.types.Panel):
    """THOR19 N-Panel — top-level controls."""

    bl_label       = "THOR19"
    bl_idname      = "THOR19_PT_MainPanel"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "THOR19"
    bl_order       = 0

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        props  = context.scene.thor19

        # ── Import ────────────────────────────────────────────────────────────
        row = layout.row(align=True)
        row.scale_y = 1.7
        row.operator("thor19.import_scene", text="Import Scene", icon="IMPORT")

        layout.separator(factor=0.3)

        # ── Reload ────────────────────────────────────────────────────────────
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.enabled = bool(props.json_path and props.json_path.strip())
        row.operator("thor19.reload_scene", text="Reload Scene", icon="FILE_REFRESH")

        # ── Loaded file path ──────────────────────────────────────────────────
        if props.json_path and props.json_path.strip():
            layout.separator(factor=0.5)
            col = layout.column(align=True)
            col.label(text="Loaded:", icon="FILE_TICK")
            path = props.json_path
            if len(path) > 46:
                path = "…" + path[-43:]
            col.label(text=path)

            # Scale info
            if props.last_scale > 0:
                col.label(text=f"Scale: {props.last_scale:.4f}  (1 bu = 1 pt)", icon="ARROW_LEFTRIGHT")


# ─────────────────────────────────────────────────────────────────────────────
#  Status panel
# ─────────────────────────────────────────────────────────────────────────────

class THOR19_PT_StatusPanel(bpy.types.Panel):
    """THOR19 import status and scene statistics."""

    bl_label       = "Status"
    bl_idname      = "THOR19_PT_StatusPanel"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "THOR19"
    bl_parent_id   = "THOR19_PT_MainPanel"
    bl_order       = 1

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        props  = context.scene.thor19

        col = layout.column(align=True)

        # ── Status message ────────────────────────────────────────────────────
        status   = props.import_status or "No scene loaded."
        is_error = status.upper().startswith("ERROR")
        is_ok    = status.startswith("OK")

        row = col.row()
        row.alert = is_error
        icon = "ERROR" if is_error else ("CHECKMARK" if is_ok else "INFO")
        row.label(text=status[:72], icon=icon)   # clamp length for narrow panel

        # ── Scene stats ───────────────────────────────────────────────────────
        if props.last_layer_count > 0 or props.last_path_count > 0:
            col.separator(factor=0.6)

            split = col.split(factor=0.55)
            left  = split.column()
            right = split.column()

            left.label(text="Collections:", icon="RENDERLAYERS")
            right.label(text=str(props.last_layer_count))

            left.label(text="Curves:", icon="CURVE_BEZCURVE")
            right.label(text=str(props.last_path_count))

        # ── Camera shortcut hint ──────────────────────────────────────────────
        if is_ok:
            col.separator(factor=0.8)
            hint = col.row()
            hint.enabled = False
            hint.label(text="Numpad 0 → Camera view", icon="CAMERA_DATA")
