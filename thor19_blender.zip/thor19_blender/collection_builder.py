"""
THOR19 — collection_builder.py  v2 UPGRADED
Create Blender Collections from THOR19 layer descriptors.

UPGRADE v2:
- ensure_root_collection performs a deep, clean purge before rebuild
  so Reload never produces duplicate collections or orphan objects.
- _purge_collection_recursive properly handles mesh/curve data-blocks.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

import bpy

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def build_collections(
    layers: List[dict],
    root_collection: bpy.types.Collection,
) -> Dict[str, bpy.types.Collection]:
    """
    Create Blender Collections for every layer descriptor in `layers`.

    Parent/child relationships are resolved iteratively so ordering in the
    JSON does not matter.  Unresolvable parents fall back to root_collection.

    Parameters
    ----------
    layers : list[dict]
    root_collection : bpy.types.Collection

    Returns
    -------
    dict[str, bpy.types.Collection]
        layer UUID → Blender Collection
    """
    uuid_to_collection: Dict[str, bpy.types.Collection] = {}
    pending: List[dict] = list(layers)
    max_passes = len(layers) + 1

    for _ in range(max_passes):
        if not pending:
            break
        still_pending: List[dict] = []

        for layer in pending:
            parent_id: Optional[str] = layer.get("parent_id")

            if parent_id is None:
                parent_coll = root_collection
            elif parent_id in uuid_to_collection:
                parent_coll = uuid_to_collection[parent_id]
            else:
                still_pending.append(layer)
                continue

            coll = _create_collection(layer["name"], parent_coll)
            uuid_to_collection[layer["id"]] = coll
            log.debug("Collection: '%s' (parent=%s)", layer["name"], parent_id)

        pending = still_pending

    # Unresolved layers → root
    for layer in pending:
        log.warning(
            "Layer '%s': parent_id '%s' not found, placed at root.",
            layer.get("name", "?"),
            layer.get("parent_id", "?"),
        )
        coll = _create_collection(layer["name"], root_collection)
        uuid_to_collection[layer["id"]] = coll

    log.info("Built %d collection(s) from %d layer(s).", len(uuid_to_collection), len(layers))
    return uuid_to_collection


def ensure_root_collection(
    scene: bpy.types.Scene,
    root_name: str = "THOR19",
) -> bpy.types.Collection:
    """
    Find or create the THOR19 root collection, fully purged and ready.

    On Reload this completely removes all child collections, objects,
    and their data-blocks before returning the empty root — guaranteeing
    zero duplicates regardless of how many times Reload is called.

    Parameters
    ----------
    scene : bpy.types.Scene
    root_name : str

    Returns
    -------
    bpy.types.Collection  (empty, linked to scene)
    """
    existing = bpy.data.collections.get(root_name)

    if existing is not None:
        _purge_collection_recursive(existing)
        log.debug("Purged existing root collection '%s'.", root_name)
        # Ensure still linked to scene after purge
        if root_name not in scene.collection.children:
            try:
                scene.collection.children.link(existing)
            except RuntimeError:
                pass  # already linked
        return existing

    root = bpy.data.collections.new(root_name)
    scene.collection.children.link(root)
    log.debug("Created root collection '%s'.", root_name)
    return root


# ─────────────────────────────────────────────────────────────────────────────
#  Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _create_collection(
    name: str,
    parent_collection: bpy.types.Collection,
) -> bpy.types.Collection:
    coll = bpy.data.collections.new(name)
    parent_collection.children.link(coll)
    return coll


def _purge_collection_recursive(collection: bpy.types.Collection) -> None:
    """
    Recursively remove all objects and sub-collections from `collection`.

    - Objects are removed with do_unlink=True (removes from all collections).
    - Object data-blocks (curves, meshes, cameras) with zero users are removed.
    - Sub-collections are unlinked then removed if user count reaches zero.
    """
    # Depth-first: purge children first
    for child in list(collection.children):
        _purge_collection_recursive(child)
        collection.children.unlink(child)
        if child.users == 0:
            bpy.data.collections.remove(child)

    # Remove objects
    for obj in list(collection.objects):
        data = obj.data  # grab data reference before removing object
        collection.objects.unlink(obj)
        bpy.data.objects.remove(obj, do_unlink=True)
        # Clean up orphan data-blocks
        if data is not None and hasattr(data, "users") and data.users == 0:
            try:
                if isinstance(data, bpy.types.Curve):
                    bpy.data.curves.remove(data)
                elif isinstance(data, bpy.types.Mesh):
                    bpy.data.meshes.remove(data)
                elif isinstance(data, bpy.types.Camera):
                    bpy.data.cameras.remove(data)
            except Exception:
                pass
